Please find all instructions on the FAQ section on my website: passmgrgui.github.io


If you do not have internet access and are wanting to reset your password, follow these steps:

WARNING: THIS WILL ERASE ALL PASSWORD DATA FOR SECURITY PURPOSES.

1. Remove the encrypted_master_password.txt in the %LOCALAPPDATA% directory or {your drive, likely C}:\{username}\AppData\Local\encrypted_master_password.txt.

2. That's it! The program will do the rest for you and you can setup everything like brand new.