from cryptography.fernet import Fernet
from os import path, environ, remove
from getpass import getuser
from platform import system
from flet import (
    Text,
    ElevatedButton,
    Theme,
    TextField,
    ScrollMode,
    icons,
    Column,
    Row,
    Page,
    app,
    SnackBar,
    IconButton,
    colors,
    ButtonStyle,
    AppBar,
)
from time import sleep
from json import load, dump
from clipboard import copy


# Constants
MAX_LENGTH = 64
MIN_LENGTH = 8

global passwords
global decrypted_master_password


# GUI variables

strength_label = None
strength_canvas = None
checkbox_var = None
window_closed_value = False
key = Fernet.generate_key()
popup = None
website_text = None
i = None


def get_critical_directory():
    if system() == "Windows":
        return path.join(environ["USERPROFILE"], "AppData", "Local")
    else:  # Assume Linux
        return f"/home/{get_current_username()}/.config/"


def get_config_directory():
    if system() == "Windows":
        return path.join(environ["USERPROFILE"], "AppData", "Local", "PasswordManager")
    else:  # Assume Linux
        return f"/home/{get_current_username()}/.config/PasswordManager"


CRITICAL_DATA_DIRECTORY = get_critical_directory()
CONFIGURATION_DIRECTORY = get_config_directory()
PASSWORD_FILE = path.join(CRITICAL_DATA_DIRECTORY, "password.txt")
ENCRYPTED_FILE = path.join(CRITICAL_DATA_DIRECTORY, "password.txt.encrypted")
KEY_FILE = path.join(CRITICAL_DATA_DIRECTORY, "key.key")
MASTER_FILE = path.join(CRITICAL_DATA_DIRECTORY, "encrypted_master_password.txt")
MASTER_KEY_FILE = path.join(CRITICAL_DATA_DIRECTORY, "master_key.key")
CONFIGURATION_FILE = path.join(CONFIGURATION_DIRECTORY, "config.json")


def generate_key():
    return Fernet.generate_key()


def load_key():
    if path.exists(KEY_FILE):
        with open(KEY_FILE, "rb") as key_file:
            return key_file.read()
    else:
        key = generate_key()
        with open(KEY_FILE, "wb") as key_file:
            key_file.write(key)
        return key


def encrypt_passwords(key):
    if path.exists(PASSWORD_FILE) and path.exists(KEY_FILE):
        with open(PASSWORD_FILE, "rb") as password_file:
            passwords = password_file.read()
            password_file.close()
        cipher_suite = Fernet(key)
        encrypted_passwords = cipher_suite.encrypt(passwords)

        with open(ENCRYPTED_FILE, "wb") as encrypted_file:
            encrypted_file.write(encrypted_passwords)
        cipher_suite = Fernet(key)
        with open(ENCRYPTED_FILE, "wb") as encrypted_file:
            encrypted_file.write(encrypted_passwords)


def load_master_key():
    if not path.exists(MASTER_KEY_FILE):
        key = Fernet.generate_key()
        with open(MASTER_KEY_FILE, "wb") as key_file:
            key_file.write(key)
    else:
        with open(MASTER_KEY_FILE, "rb") as key_file:
            key = key_file.read()
    return key


def decrypt_master_password():
    key = load_master_key()
    with open(MASTER_FILE, "rb") as encrypted_file:
        encrypted_master_password = encrypted_file.read()

    cipher_suite = Fernet(key)
    decrypted_master_password_bytes = cipher_suite.decrypt(encrypted_master_password)
    decrypted_master_password = decrypted_master_password_bytes.decode(
        "utf-8"
    )  # Convert bytes to string

    return decrypted_master_password


def decrypt_passwords():
    key = load_key()
    with open(ENCRYPTED_FILE, "rb") as encrypted_file:
        encrypted_passwords = encrypted_file.read()

    cipher_suite = Fernet(key)
    decrypted_passwords = cipher_suite.decrypt(encrypted_passwords)

    with open(PASSWORD_FILE, "wb") as password_file:
        password_file.write(decrypted_passwords)


def get_current_username():
    return getuser()


def main(page: Page):
    def on_window_event(e):
        if e.data == "close":
            key = load_key()
            encrypt_passwords(key)
            remove(PASSWORD_FILE)
            page.window_destroy()

    def encrypt_and_write_master_password(
        password,
        master_title,
        details,
        new_master_password_field,
        set_new_master_password_button,
    ):
        key = load_master_key()
        cipher_suite = Fernet(key)
        encrypted_password = cipher_suite.encrypt(password.encode("utf-8"))

        with open(MASTER_FILE, "wb") as encrypted_file:
            encrypted_file.write(encrypted_password)
        page.remove(
            master_title,
            details,
            new_master_password_field,
            set_new_master_password_button,
        )
        title = Text("Success!", weight="bold", size=26)
        details = Text(
            "Please wait 10 seconds for the program to restart, then rerun the program."
        )
        exit_now_button = ElevatedButton(
            text="Exit now", on_click=lambda e: page.window_destroy()
        )
        page.add(title, details, exit_now_button)
        for i in range(11):
            sleep(1)
            page.remove(title, details, exit_now_button)
            details = Text(
                f"Please wait {10 - i} seconds for the program to restart, then rerun the program."
            )
            page.add(title, details, exit_now_button)
            page.update()
            if 10 - i == 0:
                page.window_destroy()

    def add_password(
        website_entry, username_entry, password_entry, holding_column, add_pwd_button
    ):
        website = website_entry.value
        username = username_entry.value
        password = password_entry.value

        with open(PASSWORD_FILE, "a") as password_file:
            password_file.write(f"Website: {website}\n")
            password_file.write(f"Username: {username}\n")
            password_file.write(f"Password: {password}\n\n")

        password_file.close()
        with open(PASSWORD_FILE, "r") as password_file:
            passwords = password_file.readlines()
        page.remove(holding_column)
        holding_column = Column(
            width=250,
            expand=True,
            scroll=ScrollMode.ADAPTIVE,
            horizontal_alignment="center",
            spacing=0,
        )
        if passwords:
            for i in range(0, len(passwords), 4):
                website = passwords[i].strip()
                username = passwords[i + 1].strip()
                password = passwords[i + 2].strip()
                website_text = Text(website, size=16, selectable=True)
                username_text = Text(username, size=16, selectable=True)
                password_text = Text(password, size=16, selectable=True)
                website_row = Row(scroll=ScrollMode.ADAPTIVE, height=35, spacing=0)
                website_row.controls.extend([website_text])
                username_row = Row(scroll=ScrollMode.ADAPTIVE, height=35, spacing=0)
                username_row.controls.extend([username_text])
                password_row = Row(scroll=ScrollMode.ADAPTIVE, height=35, spacing=0)
                copy_button = IconButton(
                    icon_size=20,
                    data=password.replace("Password: ", ""),
                    icon=icons.COPY,
                    on_click=lambda e: copy(e.control.data),
                )
                password_row.controls.extend([copy_button, password_text])
                remove_button = ElevatedButton(
                    icon=icons.REMOVE_CIRCLE_OUTLINE,
                    data=[
                        i,
                        website_row,
                        username_row,
                        password_row,
                    ],
                    text="Remove",
                    on_click=lambda e: remove_password(
                        remove_from=holding_column,
                        controls=[*e.control.data, e.control],
                    ),
                )
                holding_column.controls.extend(
                    [
                        website_row,
                        username_row,
                        password_row,
                        remove_button,
                    ]
                )
            page.update()
            page.remove(website_entry, username_entry, password_entry, add_pwd_button)
            website_entry = TextField(label="Website", hint_text="www.google.com")
            username_entry = TextField(
                label="Username/Email", hint_text="jhonny@gmail.com"
            )
            password_entry = TextField(
                label="Password", hint_text="mysupersecretpassword123!"
            )
            add_pwd_button = ElevatedButton(
                text="Add",
                icon=icons.ADD,
                on_click=lambda e: add_password(
                    website_entry,
                    username_entry,
                    password_entry,
                    holding_column,
                    e.control,
                ),
            )
            page.controls.extend(
                [
                    website_entry,
                    username_entry,
                    password_entry,
                    add_pwd_button,
                    holding_column,
                ]
            )
            page.update()

    def remove_password(
        remove_from,
        controls,
    ):
        with open(PASSWORD_FILE, "r") as password_file:
            passwords = password_file.readlines()
        i = controls[0]
        entry_start = i + 1
        entry_end = entry_start + 3
        controls.remove(i)  # Calculate the end index of the entry
        controls = [*controls]

        if len(passwords) not in [3, 4, 5]:
            lines_to_keep = []
            with open(PASSWORD_FILE, "r") as file:
                lines = file.readlines()
                for line_number, line in enumerate(lines, start=1):
                    if entry_start <= line_number <= entry_end:
                        continue
                    lines_to_keep.append(line)

            # Write the updated lines back to the file
            with open(PASSWORD_FILE, "w") as pwd_file:
                pwd_file.writelines(lines_to_keep)

            if controls:
                for c in controls:
                    remove_from.controls.remove(c)
                remove_from.update()

        else:
            page.snack_bar = SnackBar(
                Text("Please create another password entry before removing this entry.")
            )
            page.snack_bar.open = True
            page.update()

    # Function to read the config.json file
    def read_config():
        try:
            with open(CONFIGURATION_FILE, "r") as config_file:
                config_data = load(config_file)
        except Exception:
            config_data = {
                "theme": "system",
            }
            write_config(config_data)
            config_data = "system"
        return config_data

    def write_config(config_data):
        with open(CONFIGURATION_FILE, "w") as config_file:
            dump(config_data, config_file, indent=4)

    def light_dark_handler(toggledarklight):
        page.theme_mode = "light" if page.theme_mode == "dark" else "dark"
        toggledarklight.selected = not toggledarklight.selected
        page.update()
        config_data = {
            "theme": page.theme_mode,
        }
        write_config(config_data)

    def login_handler(master_password_field):
        if master_password_field.value == decrypt_master_password():
            decrypt_passwords()
            with open(PASSWORD_FILE, "r") as password_file:
                passwords = password_file.readlines()
                password_file.close()
            page.remove(login_title, master_password_field, login_button)
            page.window_height = 750
            page.window_width = 750
            page.window_prevent_close = True
            page.on_window_event = on_window_event
            if page.theme_mode == "dark":
                toggledarklight = IconButton(
                    on_click=lambda e: light_dark_handler(toggledarklight),
                    icon="light_mode",
                    selected_icon="dark_mode",
                    style=ButtonStyle(
                        # change color if light and dark
                        color={"": colors.WHITE, "selected": colors.BLACK}
                    ),
                )
            else:
                toggledarklight = IconButton(
                    on_click=lambda e: light_dark_handler(toggledarklight),
                    icon="dark_mode",
                    selected_icon="light_mode",
                    style=ButtonStyle(
                        # change color if light and dark
                        color={"": colors.BLACK, "selected": colors.WHITE}
                    ),
                )

            nav_bar = AppBar(
                actions=[toggledarklight],
            )
            website_entry = TextField(label="Website", hint_text="www.google.com")
            username_entry = TextField(
                label="Username/Email", hint_text="jhonny@gmail.com"
            )
            password_entry = TextField(
                label="Password", hint_text="mysupersecretpassword123!"
            )
            add_pwd_button = ElevatedButton(
                text="Add",
                icon=icons.ADD,
                on_click=lambda e: add_password(
                    website_entry,
                    username_entry,
                    password_entry,
                    holding_column,
                    add_pwd_button=e.control,
                ),
            )

            page.add(
                title,
                website_entry,
                username_entry,
                password_entry,
                add_pwd_button,
                nav_bar,
            )
            holding_column = Column(
                width=250,
                expand=True,
                scroll=ScrollMode.ADAPTIVE,
                horizontal_alignment="center",
                spacing=0,
            )
            if passwords:
                for i in range(0, len(passwords), 4):
                    website = passwords[i].strip()
                    username = passwords[i + 1].strip()
                    password = passwords[i + 2].strip()
                    website_text = Text(website, size=16, selectable=True)
                    username_text = Text(username, size=16, selectable=True)
                    password_text = Text(password, size=16, selectable=True)
                    website_row = Row(scroll=ScrollMode.ADAPTIVE, height=35, spacing=0)
                    website_row.controls.extend([website_text])
                    username_row = Row(scroll=ScrollMode.ADAPTIVE, height=35, spacing=0)
                    username_row.controls.extend([username_text])
                    password_row = Row(scroll=ScrollMode.ADAPTIVE, height=35, spacing=0)
                    copy_button = IconButton(
                        icon_size=20,
                        data=password.replace("Password: ", ""),
                        icon=icons.COPY,
                        on_click=lambda e: copy(e.control.data),
                    )
                    password_row.controls.extend([copy_button, password_text])
                    remove_button = ElevatedButton(
                        icon=icons.REMOVE_CIRCLE_OUTLINE,
                        data=[
                            i,
                            website_row,
                            username_row,
                            password_row,
                        ],
                        text="Remove",
                        on_click=lambda e: remove_password(
                            remove_from=holding_column,
                            controls=[*e.control.data, e.control],
                        ),
                    )
                    holding_column.controls.extend(
                        [
                            website_row,
                            username_row,
                            password_row,
                            remove_button,
                        ]
                    )
                page.add(holding_column)
        else:
            page.snack_bar = SnackBar(
                Text(
                    "Incorrect master password. You can reset it by following the instructions in the README.txt on install or the FAQ on our website."
                )
            )
            page.snack_bar.open = True
            page.update()

    if path.exists(MASTER_FILE) and path.exists(MASTER_KEY_FILE):
        page.title = "Login"
        page.window_width = 420
        page.window_height = 420
        page.horizontal_alignment = "center"
        page.vertical_alignment = "center"
        login_title = Text("Login", weight="bold", size=26)
        master_password_field = TextField(
            label="Password",
            hint_text="mysupersecretpassword123!",
            password=True,
            can_reveal_password=True,
        )
        login_button = ElevatedButton(
            text="Login", on_click=lambda e: login_handler(master_password_field)
        )
        page.add(login_title, master_password_field, login_button)
    else:
        page.title = "Set your master password..."
        page.window_width = 420
        page.window_height = 420
        page.horizontal_alignment = "center"
        page.vertical_alignment = "center"
        master_title = Text("Set your master password...", weight="bold", size=26)
        details = Text(
            "It looks like you don't have a master password set yet! Lets get you started.",
        )
        new_master_password_field = TextField(
            label="New password", hint_text="mysupersecretpassword123!"
        )
        set_new_master_password_button = ElevatedButton(
            text="Confirm",
            on_click=lambda e: encrypt_and_write_master_password(
                new_master_password_field.value,
                master_title,
                details,
                new_master_password_field,
                set_new_master_password_button,
            ),
        )
        page.add(
            master_title,
            details,
            new_master_password_field,
            set_new_master_password_button,
        )

    if not path.exists(CONFIGURATION_FILE):
        with open(CONFIGURATION_FILE, "w") as config_file:
            config_data = {
                "theme": "dark",
            }
            dump(config_data, config_file)

    page.title = "Password Manager"
    page.window_width = 420
    page.window_height = 420
    page.window_maximizable = False
    config = read_config()
    theme = config["theme"]
    if theme == "dark":
        page.theme_mode = "dark"
    elif theme == "light":
        page.theme_mode = "light"
    page.update()
    page.theme = Theme(font_family="OpenSans")
    page.fonts = {
        "OpenSans": "https://rawgithubusercontent.com/googlefonts/opensans/raw/main/fonts/ttf/OpenSans-Regular.ttf",
    }
    title = Text("Password Manager", weight="bold", size=26)


if __name__ == "__main__":
    app(target=main)
